package com.yinhe.utils;

import java.util.UUID;

public class CommonsUtils {

	//����uuid
	public static String getUUID(){
		return UUID.randomUUID().toString();
	}
}
