package com.yinhe.bean;

public class CartItem {

	  private Product product;//��Ʒ
	  
	  private int buyNum;//����
	  
	  private double subTotal;//С��

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public int getBuyNum() {
		return buyNum;
	}

	public void setBuyNum(int buyNum) {
		this.buyNum = buyNum;
	}

	public double getSubTotal() {
		return subTotal;
	}

	public void setSubTotal(double subTotal) {
		this.subTotal = subTotal;
	}
	  
	  
	  
}
